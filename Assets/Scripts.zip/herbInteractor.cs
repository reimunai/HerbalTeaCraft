using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class herbInteractor : XRGrabInteractable
{
    [Header("Herbal Info")]
    public Ingredient ingredient;
    public string IngredientName;
    public string IngredientInfo;
    public float weight;
    public HUDControl control;
    private Vector3 originPosition;
    
    private void Start()
    {
        originPosition = transform.position;
        control = FindFirstObjectByType<HUDControl>();
    }
    //����ܳ�Զ���λ
    protected override void OnSelectExited(SelectExitEventArgs args)
    {
        base.OnSelectExited(args);

            Transport();
    }
    public void Transport() 
    {
        var rb=GetComponent<Rigidbody>();
        if (rb != null)
        {
            // ֻ�з��˶�ѧ������������ٶ�
            if (!rb.isKinematic)
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
            else
            {
                // �����˶�ѧ���壬ֱ������λ�ú���ת
                rb.position = originPosition;
            }
        }
        transform.position = originPosition;
    }

    protected override void OnHoverEntered(HoverEnterEventArgs args)
    {
        base.OnHoverEntered(args);
        //control.ShowHerbalInfo(IngredientName, IngredientInfo);
        control.ShowHerbalInfo(ingredient);
    }
    protected override void OnHoverExited(HoverExitEventArgs args)
    {
        base.OnHoverExited(args);
        control.HideHerbalInfo();
    }
}
